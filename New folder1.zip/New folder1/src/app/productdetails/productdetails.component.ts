import { Component, OnInit } from '@angular/core';
import { Product } from '../Product';
import { AdminService } from '../admin.service';

@Component({
  selector: 'app-productdetails',
  templateUrl: './productdetails.component.html',
  styleUrls: ['./productdetails.component.css']
})
export class ProductdetailsComponent implements OnInit {
  product: Product[];

  constructor(private httpClientService: AdminService) { }

  ngOnInit() {
    this.httpClientService.showProducts().subscribe(data => this.product = data);
}
deleteProduct(product) {
  alert(product.productId);
  this.httpClientService.deleteProduct(product.productId).subscribe(data => console.log(data));
}
}
