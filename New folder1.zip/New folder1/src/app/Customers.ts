
export class Customer {

  customerId: number ;
 customerName:  String ;
  customerMobile: number;
 customerEmail: String  ;
  customerPassword: String;
 customerHistory: String ;
 customerCartId: String;
 customerWallet: number;
customerEncryptedPassword: String ;

}
