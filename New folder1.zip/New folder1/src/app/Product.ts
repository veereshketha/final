export class Product {
productAvailability;
 productBrand;
 productCategory;
 productDiscount;
 productFeedback;
 productId;
 productImage;
 productName;
 productPrice: number;
 productQuantity: number;
   productRating: number;
 productType: String;

 }
