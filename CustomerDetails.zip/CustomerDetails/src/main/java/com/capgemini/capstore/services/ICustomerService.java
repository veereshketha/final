package com.capgemini.capstore.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.CapgProduct;
import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.Merchant;

@Service
public interface ICustomerService {

	List<Customer> findAllCustomers();
	List<CapgProduct> findAllProducts();
	List<Merchant> findAllMerchants();
	public void deleteCustomer(int customerId);

}

