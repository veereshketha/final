package com.capgemini.capstore.dao;

import java.util.List;

import com.capgemini.capstore.beans.CapgProduct;
import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.Merchant;

public interface ICustomerDao {

	List<Customer> findAllCustomers();
	List<CapgProduct> findAllProducts();
	List<Merchant> findAllMerchants();
	public void deleteCustomer(int customerId);
	
	
	
}
