package com.capgemini.capstore.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.CapgProduct;
import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.Merchant;
import com.capgemini.capstore.dao.ICustomerDao;


@Service
public class CustomerServiceImpl implements ICustomerService {

	@Autowired
	ICustomerDao dao;
	
	
	public void deleteCustomer(int customerId) {
		System.out.println(customerId);
		 dao.deleteCustomer(customerId) ;
	}

	public void deleteMerchant(int merchantId) {
		System.out.println(merchantId);
		 dao.deleteMerchant(merchantId) ;
	}
	public void deleteProduct(int productId) {
		// TODO Auto-generated method stub
		dao.deleteProduct(productId);
	}

	@Override
	public List<Customer> findAllCustomers() {
		return dao.findAllCustomers();
	}


	@Override
	public List<CapgProduct> findAllProducts() {
		return dao.findAllProducts();
	}


	@Override
	public List<Merchant> findAllMerchants() {
	return dao.findAllMerchants();
	}

	
}
