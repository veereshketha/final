import { Component, OnInit } from '@angular/core';
import { AdminService } from '../admin.service';
import { Customer } from '../Customers';


@Component({
  selector: 'app-customerdetails',
  templateUrl: './customerdetails.component.html',
  styleUrls: ['./customerdetails.component.css']
})
export class CustomerdetailsComponent implements OnInit {


  customer: Customer[];


  constructor( private httpClientService: AdminService) {}

  ngOnInit()  {
    this.httpClientService.showCustomers().subscribe(data => this.customer = data);
}


backtoadmin(cust) {
  alert(cust.customerId);
  this.httpClientService.deleteCustomer(cust.customerId).subscribe(data => console.log(data));
}





}
