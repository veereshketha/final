import { Component, OnInit } from '@angular/core';
import { AdminService } from '../admin.service';
import { Merchant } from '../Merchant';

@Component({
  selector: 'app-allmerchants',
  templateUrl: './allmerchants.component.html',
  styleUrls: ['./allmerchants.component.css']
})
export class AllmerchantsComponent implements OnInit {
merchant: Merchant[];
  constructor(private httpClientService: AdminService) { }

  ngOnInit() {
    this.httpClientService.showMerchants().subscribe(data => this.merchant = data);
  }

}
