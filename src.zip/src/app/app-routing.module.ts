import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminComponent } from './admin/admin.component';
import { AdminpageComponent } from './adminpage/adminpage.component';
import { CustomerdetailsComponent } from './customerdetails/customerdetails.component';
import { InventoryComponent } from './inventory/inventory.component';
import { AddMerchantComponent } from './add-merchant/add-merchant.component';
import { MerchantDetailsComponent } from './merchant-details/merchant-details.component';
import { AllmerchantsComponent } from './allmerchants/allmerchants.component';


const routes: Routes = [
  {path: 'adminlogin', component: AdminComponent},
  {path: 'adminPage', component: AdminpageComponent},
  {path: 'customerDetails', component: CustomerdetailsComponent},
  {path: 'inventoryDetails', component: InventoryComponent},
  {path: 'merchantDetails', component: MerchantDetailsComponent},
  {path: 'addMerchant', component: AddMerchantComponent},
  {path: 'allMerchants', component: AllmerchantsComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
