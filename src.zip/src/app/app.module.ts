import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import {FormsModule} from '@angular/forms';
import {RouterModule} from '@angular/router';
import {HttpClientModule} from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AdminComponent } from './admin/admin.component';
import { AdminpageComponent } from './adminpage/adminpage.component';
import { CustomerdetailsComponent } from './customerdetails/customerdetails.component';
import { InventoryComponent } from './inventory/inventory.component';
import { AdminService } from './admin.service';
import { AddMerchantComponent } from './add-merchant/add-merchant.component';
import { AllmerchantsComponent } from './allmerchants/allmerchants.component';
import { MerchantDetailsComponent } from './merchant-details/merchant-details.component';




@NgModule({
  declarations: [
    AppComponent,
    AdminComponent,
    AdminpageComponent,
    CustomerdetailsComponent,
    InventoryComponent,
    AddMerchantComponent,
    AllmerchantsComponent,
    MerchantDetailsComponent

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    RouterModule,
    HttpClientModule
  ],
  providers: [AdminService],
  bootstrap: [AppComponent]
})
export class AppModule { }
