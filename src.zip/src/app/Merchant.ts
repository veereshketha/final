export class Merchant {
  merchantEmail: String ;
 merchantName: String;
   merchantAddress: String;
    merchantMobile: String;
    merchantPassword: String;
    merchantType: String;

}
