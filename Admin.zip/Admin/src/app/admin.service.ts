import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { Observable } from '../../node_modules/rxjs';




@Injectable({
  providedIn: 'root'
})
export class AdminService {

  private baseUrl = 'localhost:9090';
  private baseUrl1 = 'http://localhost:9090/delete';
  constructor(private http: HttpClient , private route: Router) { }



// ------admin sign-in---------------

  login(data) {
    if (data.adminName === 'capg' && data.adminPassword === 'capg123') {
      alert('Hello Admin');
      this.route.navigate(['/adminPage']);
    } else {
      alert('Invalid Credentials');
    }
  }

  showCustomers(): Observable<any> {
    return this.http.get('http://localhost:9090/customers');
  }

  deleteCustomer(id: number): Observable<any> {
    return this.http.delete(`http://localhost:9090/delete/` + id);
  }

  showMerchants(): Observable<any> {
    return this.http.get('http://localhost:9090/merchants');
  }


  showProducts(): Observable<any> {
    return this.http.get('http://localhost:9090/products');
  }


}
