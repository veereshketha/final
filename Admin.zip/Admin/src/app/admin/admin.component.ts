import { Component, OnInit } from '@angular/core';
import { AdminService } from '../admin.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {



  constructor(private service: AdminService) {



   }

  ngOnInit() {
  }
login(adminSignin) {
  this.service.login(adminSignin);

}

  // login(data) {
  //   if (data.adminName === 'capg' && data.adminPassword === 'capg123') {
  //     alert('Hello Admin');
  //     this.route.navigate(['/adminPage']);
  //   } else {
  //     alert('Invalid Credentials');
  //   }
  // }



}
